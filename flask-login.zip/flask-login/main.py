from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.secret_key = 'your_secret_key' # In a real application, make this a strong, random key from environment variables

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///users.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(25), unique=True, nullable=False)
    password_hash = db.Column(db.String(150), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)




@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

#Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip() # Use .strip() to remove leading/trailing whitespace
        password = request.form['password'].strip()

        # Add validation for empty fields
        if not username or not password:
            return render_template('index.html', error='Please enter both username and password.')

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            return render_template('index.html', error='Invalid username or password')
    return render_template('index.html') # Render the form for GET requests

#Register
@app.route("/register", methods=['POST'])
def register():
    username = request.form['username'].strip()
    password = request.form['password'].strip()

    # Add validation for empty fields
    if not username or not password:
        return render_template("index.html", error="Please enter both username and password to register.")

    user = User.query.filter_by(username=username).first()
    if user:
        return render_template("index.html", error="User already registered!")
    else:
        new_user = User(username=username)
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()
        session['username'] = username
        return redirect(url_for('dashboard'))

#Dashboard
@app.route("/dashboard")
def dashboard():
    if 'username' in session:
        return render_template("dashboard.html", username=session['username'])
    return redirect(url_for('home'))

#Logout
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))




if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)